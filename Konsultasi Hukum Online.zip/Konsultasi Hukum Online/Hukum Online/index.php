<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SaifulMLaw</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .advokat-section {
      padding: 40px;
      background-color: #f9f9f9;
    }

    .advokat-list {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }

    .advokat-card {
      background: #fff;
      border: 1px solid #ccc;
      border-radius: 10px;
      width: 280px;
      padding: 20px;
      text-align: center;
    }

    .advokat-card img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 10px;
    }

    .lihat-semua {
      margin-top: 20px;
      text-align: center;
    }

    .lihat-semua a button {
      padding: 10px 20px;
      font-size: 16px;
      background: #004aad;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }

    body {
      font-family: Arial, sans-serif;
      margin: 40px;
      background-color: #ffffff;
      color: #333;
    }

    .container {
      max-width: 1000px;
      margin: auto;
    }

    header h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    section.konsultasi {
      margin-bottom: 40px;
    }

    .card-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 24px;
    }

    @media (min-width: 768px) {
      .card-container {
        flex-direction: row;
      }
    }

    .card {
      background: #fff;
      border: 1px solid #ddd;
      padding: 20px;
      border-radius: 10px;
      width: 100%;
      max-width: 300px;
      margin: auto;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      text-align: left;
    }

    .icon {
      font-size: 32px;
      color: #f59e0b;
      margin-bottom: 10px;
    }

    .card h3 {
      margin-bottom: 10px;
      font-size: 18px;
      color: #111827;
    }

    .card p {
      margin: 5px 0;
      font-size: 14px;
    }

    .card ul {
      margin: 10px 0;
      padding-left: 20px;
      font-size: 14px;
      color: #4b5563;
    }

    .card a {
      display: block;
      text-align: center;
      background: #1d4ed8;
      color: white;
      text-decoration: none;
      padding: 10px;
      border-radius: 5px;
      margin-top: 10px;
      font-size: 14px;
    }

    .card a:hover {
      background: #1e40af;
    }

    section.layanan-khusus h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .layanan {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      margin-bottom: 30px;
    }

    .layanan-item {
      text-align: center;
      width: 100px;
    }

    .layanan-item .icon {
      background: #f59e0b;
      border-radius: 50%;
      width: 60px;
      height: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: auto;
      color: white;
      font-size: 24px;
      margin-bottom: 10px;
    }

    .layanan-item p {
      font-size: 14px;
      font-weight: 600;
    }

    section.footer {
      text-align: center;
      font-size: 14px;
    }

    .footer a {
      display: inline-block;
      margin-top: 5px;
      background: #1d4ed8;
      color: white;
      padding: 8px 14px;
      border-radius: 5px;
      text-decoration: none;
    }

    .footer a:hover {
      background: #1e40af;
    }

  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar">
    <div class="logo">
      <img src="fotoLogo.png" alt="Logo SaifulMLaw">
    </div>
    <ul class="nav-links">
      <li class="active"><a href="#">Beranda</a></li>
      <li><a href="#">Langkah Hukum</a></li>
      <li><a href="#">Riwayat</a></li>
      <li><a href="#">Masuk</a></li>
    </ul>
  </nav>

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-text">
      <h1>Butuh bantuan hukum?<br>Jangan Ragu!</h1>
      <p>Kami siap membantu dengan layanan hukum online yang transparan, profesional, dan terjangkau</p>
    </div>
    <div class="hero-image">
      <img src="hero-devices.png" alt="Chatting with Lawyer">
    </div>
  </section>

  <!-- 60+ Mitra Advokat Pilihan -->
  <section class="advokat-section">
    <h2 style="text-align: center;">60+ Mitra Advokat Pilihan</h2>

    <div class="advokat-list">
      <?php
      $conn = new mysqli("localhost", "root", "", "layanan_hukum");
      if ($conn->connect_error) {
          die("Koneksi gagal: " . $conn->connect_error);
      }

      $result = $conn->query("SELECT * FROM advokat LIMIT 6");
      while ($row = $result->fetch_assoc()):
      ?>
        <div class="advokat-card">
          <img src="uploads/<?= $row['foto'] ?>" alt="Foto Advokat">
          <h3><?= $row['nama'] ?></h3>
          <p><strong>Keahlian:</strong> <?= $row['keahlian'] ?></p>
          <p><strong>Pendidikan:</strong> <?= $row['pendidikan'] ?></p>
          <a href="detail_advokat.php?id=<?= $row['id'] ?>">Lihat Profil</a>
        </div>
      <?php endwhile; ?>
    </div>

    <div class="lihat-semua">
      <a href="semua_advokat.php">
        <button>Lihat Semua Mitra Advokat</button>
      </a>
    </div>
  </section>

  <div class="container">

    <header>
      <h1>Layanan Konsultasi Hukum</h1>
    </header>

    <section class="konsultasi">
      <div class="card-container">
        <div class="card">
          <div class="icon">💬</div>
          <h3>Konsultasi via Chat</h3>
          <p>Rp30.000 untuk 30 menit</p>
          <ul>
            <li>Konsultasi tahap awal</li>
            <li>Advokat dipilihkan oleh sistem</li>
          </ul>
          <a href="#">Pesan Konsultasi</a>
        </div>
        <div class="card">
          <div class="icon">📞</div>
          <h3>Konsultasi via Telepon</h3>
          <p>Rp350.000 untuk 30 menit</p>
          <ul>
            <li>Diskusi lebih mendalam</li>
            <li>Bebas pilih advokat dan jadwal</li>
          </ul>
          <a href="#">Pesan Konsultasi</a>
        </div>
      </div>
    </section>

    <section class="layanan-khusus">
      <h2>Layanan Khusus</h2>
      <div class="layanan">
        <div class="layanan-item">
          <div class="icon">📄</div>
          <p>Perceraian</p>
        </div>
        <div class="layanan-item">
          <div class="icon">📄</div>
          <p>Dokumen Bisnis</p>
        </div>
        <div class="layanan-item">
          <div class="icon">📄</div>
          <p>Ketenagakerjaan</p>
        </div>
        <div class="layanan-item">
          <div class="icon">📄</div>
          <p>Bisnis</p>
        </div>
        <div class="layanan-item">
          <div class="icon">📄</div>
          <p>Waris</p>
        </div>
        <div class="layanan-item">
          <div class="icon">📄</div>
          <p>Wasiat</p>
        </div>
      </div>
    </section>

    <section class="footer">
      <p>Tidak menemukan layanan hukum yang Anda cari?</p>
      <a href="#">Layanan Hukum Lainnya</a>
    </section>
</body>
</html>