<?php
// Koneksi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "layanan_hukum";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id = $_GET['id'] ?? 0;

// Ambil data advokat
$advokat = $conn->query("SELECT * FROM advokat WHERE id = $id")->fetch_assoc();

// Ambil artikel terkait
$artikel = $conn->query("SELECT * FROM artikel WHERE advokat_id = $id");

// Ambil layanan terkait
$layanan = $conn->query("SELECT * FROM layanan WHERE advokat_id = $id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profil Advokat - <?php echo $advokat['nama']; ?></title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .profile, .artikel, .layanan { margin-bottom: 30px; }
        .foto { width: 120px; border-radius: 50%; }
        .card { border: 1px solid #ccc; padding: 10px; margin-top: 10px; border-radius: 6px; }
    </style>
</head>
<body>

<h2>Profil Advokat</h2>
<div class="profile">
    <img class="foto" src="uploads/<?php echo $advokat['foto']; ?>" alt="Foto Advokat">
    <h3><?php echo $advokat['nama']; ?></h3>
    <p><strong>Pendidikan:</strong> <?php echo $advokat['pendidikan']; ?></p>
    <p><strong>Keahlian:</strong> <?php echo $advokat['keahlian']; ?></p>
    <p><strong>Pengalaman:</strong> <?php echo $advokat['pengalaman']; ?></p>
</div>

<div class="artikel">
    <h3>Artikel Terkait</h3>
    <?php while ($a = $artikel->fetch_assoc()): ?>
        <div class="card">
            <h4><?php echo $a['judul']; ?></h4>
            <p><?php echo substr($a['isi'], 0, 150); ?>...</p>
        </div>
    <?php endwhile; ?>
</div>

<div class="layanan">
    <h3>Layanan yang Ditawarkan</h3>
    <?php while ($l = $layanan->fetch_assoc()): ?>
        <div class="card">
            <h4><?php echo $l['nama_layanan']; ?> - Rp<?php echo number_format($l['harga'], 2, ',', '.'); ?></h4>
            <p><?php echo $l['deskripsi']; ?></p>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
