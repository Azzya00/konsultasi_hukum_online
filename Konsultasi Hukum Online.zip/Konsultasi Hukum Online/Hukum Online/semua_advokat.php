<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "layanan_hukum");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pilih Mitra Advokat</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    /* Header kuning di bagian atas */
    .header-kuning {
      background-color: #d29e00;
      padding: 40px 20px;
      color: white;
      text-align: center;
      margin-bottom: 30px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .header-wrapper {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }

    .header-wrapper img {
      height: 90px;
      width: auto;
    }

    .header-wrapper h1 {
      font-size: 32px;
      font-weight: bold;
      margin: 0;
    }

    .advokat-section {
      padding: 40px;
      background-color: #f9f9f9;
    }

    .advokat-list {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }

    .advokat-card {
      background: #fff;
      border: 1px solid #ccc;
      border-radius: 10px;
      width: 280px;
      padding: 20px;
      text-align: center;
      transition: 0.3s ease;
    }

    .advokat-card:hover {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .advokat-card img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 10px;
    }

    .advokat-card h3 {
      font-size: 18px;
      margin: 10px 0;
    }

    .advokat-card p {
      font-size: 14px;
      color: #555;
      margin: 5px 0;
    }

    .advokat-card a {
      display: inline-block;
      margin-top: 10px;
      color: #004aad;
      text-decoration: none;
      font-weight: bold;
    }

    .advokat-card a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<!-- Header Kuning -->
<div class="header-kuning">
  <div class="header-wrapper">
    <img src="fotoLogo.png" alt="Logo SaifulMLaw">
    <h1>Pilih Mitra Advokat</h1>
  </div>
</div>

<!-- Daftar Advokat -->
<section class="advokat-section">
  <div class="advokat-list">
    <?php
    $result = $conn->query("SELECT * FROM advokat");
    while ($row = $result->fetch_assoc()):
    ?>
      <div class="advokat-card">
        <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="Foto Advokat">
        <h3><?= htmlspecialchars($row['nama']) ?></h3>
        <p><strong>Keahlian:</strong> <?= htmlspecialchars($row['keahlian']) ?></p>
        <p><strong>Pendidikan:</strong> <?= htmlspecialchars($row['pendidikan']) ?></p>
        <a href="detail_advokat.php?id=<?= $row['id'] ?>">Lihat Profil</a>
      </div>
    <?php endwhile; ?>
  </div>
</section>

</body>
</html>
